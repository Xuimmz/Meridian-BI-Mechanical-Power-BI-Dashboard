# Meridian · Mechanical Power BI Dashboard

Meridian is an open-source mechanical-style Power BI cockpit for a simulated cross-border retail business. It follows a year of operations across five markets, three channels and five product categories. Navy instrument panels, chamfered outlines, and cyan chart marks evoke the reference cockpit. Each page uses its own layout and accent to make its main question easy to find.

### Offline HTML preview

Open `preview.html` in your browser after extracting the ZIP. The preview embeds the sample data and artwork in one file. Use the bottom navigation to switch pages and the market and channel filters to compare segments wherever you are in the report.

On the overview map, hover over a market or tab to it to see revenue, orders, and margin. Select a bubble to filter the dashboard and use **Clear market** to return to the full view. Bubble area encodes net revenue, and amber marks the current selection.

The background artwork provides the technical grid, accent lines and instrument panel outlines. SVG charts and HTML tables are rendered over that artwork. Filter changes recompute rates from their numerator and denominator for the selected rows.

### Editable Power BI report

Open `MeridianCockpit.pbip` in Power BI Desktop for Windows. Keep the `.Report` and `.SemanticModel` folders next to the project. If required by your Desktop build, enable Power BI Project or the enhanced report format in **File → Options and settings → Options → Preview features**. On the first open, use **Home → Refresh** if visuals are empty.

The report uses native Power BI visuals, DAX measures and synchronized market and channel slicers. Ctrl-click the on-canvas navigation in Desktop edit mode. The sample table is embedded in the semantic model and refreshes offline. A companion CSV exposes all 900 source rows for inspection.

The overview uses the native **Azure Maps** visual. Its markers cross-filter the KPI cards, trend charts, and market table on that page. Azure Maps needs internet access and may need to be enabled by your Power BI administrator. The HTML map works offline. [Azure Maps setup](https://learn.microsoft.com/azure/azure-maps/power-bi-visual-get-started)

| Page | What it answers |
| --- | --- |
| Operations overview | Where are the five markets, and how do their revenue, order and profit trends compare? |
| Markets & channels | Which channels account for revenue, and how does net revenue per order differ by market? |
| Products & profitability | Which categories produce the most contribution profit? |
| Cross-border fulfillment | Where do late orders and longer transit times concentrate? |
| Refunds & risk | Where do refunds and flagged orders occur most often? |

### Metric definitions and reuse

- Net revenue is gross sales less refunds. Contribution profit subtracts product cost, ad spend and freight from net revenue.
- Refund and flag rates are the relevant order counts divided by total orders. On-time rate is on-time orders divided by orders. Average transit time uses total transit days divided by orders.
- All observations are synthetic, cover January through December 2025, and use USD. A flagged order represents a simulated review signal.
- `design/Meridian-Mechanical.json` can be imported as a Power BI report theme. Page-specific frame PNGs are in `.Report/StaticResources/RegisteredResources/`. The canvas is 1600 × 900.

### Five-page gallery

The following screenshots show the offline HTML preview using the same simulated data.

**Operations overview**

![Operations overview](readme-assets/overview-en.jpg)

A selected market on the interactive overview map.

![Global map with a market selected](readme-assets/overview-map-en.jpg)

**Markets & channels**

![Markets & channels](readme-assets/markets-en.jpg)

**Products & profitability**

![Products & profitability](readme-assets/products-en.jpg)

**Cross-border fulfillment**

![Cross-border fulfillment](readme-assets/delivery-en.jpg)

**Refunds & risk**

![Refunds & risk](readme-assets/risk-en.jpg)

[Visual reference](https://mp.weixin.qq.com/s/sNb0NIlz59H791UmsaCBNw) · [Power BI projects](https://learn.microsoft.com/en-us/power-bi/developer/projects/projects-overview) · [Natural Earth basemap](https://www.naturalearthdata.com/about/terms-of-use/)
